Development moved to https://gitlab.com/blacknet-ninja

https://imcoin.org/ aims to continue on IMCoin chain.
